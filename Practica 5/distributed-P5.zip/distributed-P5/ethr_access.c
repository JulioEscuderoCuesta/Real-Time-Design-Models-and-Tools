#include <assert.h>
#include <drivers/if_ether.h>
#include <drivers/eth_ioctl.h>
#include <drivers/osdep.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>

#if 0
#include <stdio.h>
#define DEBUG(x,args...) printf("%s: " x, __func__ , ##args)
#else
#define DEBUG(x,args...)
#endif

typedef struct {
        struct ethhdr header;
        char data[ETH_DATA_LEN];
} eth_frame_t;

#define LOGGER_PROTOCOL 0x1010


/*
Global variables for local computer
*/
static int fd; // File descriptor
static struct ether_addr src_mac; // Mac address of sending computer

static pthread_mutex_t m_send;
static pthread_mutexattr_t m_attr;

/*
Open and initialize the device
*/

void initialize ()
{
   int err;

   bool is_station1;
   char mac_str[18];
   unsigned short protocol = LOGGER_PROTOCOL;

   fd = open("/dev/eth0", O_RDWR);
   assert(fd != -1);

   err = ioctl(fd, ETH_HWADDR, src_mac.ether_addr_octet);
   assert(err == 0);

   err = ioctl(fd, SET_PROTOCOL_FILTER, (void *)&protocol);
   assert(err == 0);

   ether_ntoa (&src_mac, mac_str);
   DEBUG("I am %s\n", mac_str);

   // Create the mutex
   pthread_mutexattr_init(&m_attr);
   if (pthread_mutex_init(&m_send,&m_attr)!= 0) {
       printf ("mutex_init\n"); exit(1);
   }

}


/*
Send a message to the destination station
*/

void send (const char *dest_station, const char *msg)
{
   int err, count;
   eth_frame_t eth_frame;
   struct ether_addr dest_mac;
   char mac_str[18];
   unsigned short protocol = LOGGER_PROTOCOL;

   pthread_mutex_lock(&m_send);
   err = ether_aton(dest_station, &dest_mac);
   assert(err == 0);

   *(struct ether_addr * )eth_frame.header.h_dest = dest_mac;
   *(struct ether_addr * )eth_frame.header.h_source = src_mac;
   eth_frame.header.h_proto= htons(LOGGER_PROTOCOL);
   strncpy(eth_frame.data, msg, ETH_FRAME_LEN);

   ether_ntoa (&dest_mac, mac_str);
   DEBUG("sending bytes to %s\n", mac_str);

   count = write(fd, &eth_frame, sizeof(eth_frame));
   assert (count > 0);

   pthread_mutex_unlock(&m_send);
}

/*
Receive a message
*/

void receive (char *msg)
{
   int count;
   eth_frame_t read_frame;
   struct ether_addr dest_mac;
   char mac_str[18];


   DEBUG("receiving bytes\n");
   count = read(fd, &read_frame, ETH_FRAME_LEN);
   assert (count > 0);
   ether_ntoa ((struct ether_addr *)&read_frame.header.h_source, mac_str);
   DEBUG("received %d bytes from %s: %s\n",
          count, mac_str, read_frame.data);

   strncpy(msg, read_frame.data, sizeof(read_frame.data));
   
}



