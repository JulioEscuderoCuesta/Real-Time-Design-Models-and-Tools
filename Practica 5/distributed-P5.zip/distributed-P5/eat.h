#ifndef _EAT_H
#define _EAT_H

#include <time.h>

/**
 * @file eat.h
 **/

extern void inline eat(const struct timespec *cpu_time);

#endif
