
// Lab. PCs
#define STATION_1 "00:30:64:07:A2:63"
#define STATION_2 "00:30:64:09:92:DE" 


/*
Open and initialize the device
*/

void initialize ();

/*
Send a message to the destination station
*/

void send (const char *dest_station, const char *msg);

/*
Receive a message
*/

void receive (char *msg);




